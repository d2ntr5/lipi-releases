// Lipi 자막 연결 — 백그라운드
// 탭의 자막 글자를 이 맥의 Lipi 앱(127.0.0.1)으로 보낸다. 인터넷으로는 보내지 않는다.
// 크롬은 쉬는 동안 이 백그라운드를 껐다 켜므로, 탭마다의 상태는 페이지 쪽(content.js)이 들고 설정은 storage 에 둔다.
const PORT = 47833;
// Lipi 가 켜져 있는지 먼저 묻는 곳. 꺼진 Lipi 에 WebSocket 을 열면 크롬이 막을 수 없는 오류 기록을 남기므로,
// fetch 로 물어 대답이 있을 때만 연결한다 (fetch 실패는 오류 기록에 남지 않음).
const PING_URL = 'http://127.0.0.1:47834/lipi';
const VERSION = chrome.runtime.getManifest().version;
const DEFAULT_CONFIG = { send: true, hideSite: false, sites: { f1tv: true, youtube: true } };

let ws = null;
let retry = null;
let backoff = 3000;
let probing = false;
let appVersion = null;
// 자막 사이트를 보는 동안만 Lipi 에 연결을 시도한다 (Lipi 가 꺼져 있을 때 오류 기록이 쌓이지 않게)
let lastActivity = 0;
const ACTIVE_FOR = 60000;
function touch() {
  lastActivity = Date.now();
  if (!connected() && !retry && !probing) connect();
}
function active() { return Date.now() - lastActivity < ACTIVE_FOR; }

function connected() { return !!ws && ws.readyState === WebSocket.OPEN; }

async function connect() {
  if (probing || (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN))) return;
  probing = true;
  let up = false;
  try {
    const r = await fetch(PING_URL, { cache: 'no-store', signal: AbortSignal.timeout(2000) });
    up = r.ok && (await r.text()) === 'lipi';
  } catch (e) {}
  probing = false;
  if (!up) { schedule(); return; }
  if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) return;
  try {
    ws = new WebSocket(`ws://127.0.0.1:${PORT}/lipi`);
  } catch (e) {
    schedule();
    return;
  }
  ws.onopen = () => {
    backoff = 3000;
    post({ type: 'hello', version: VERSION });
  };
  ws.onmessage = (ev) => {
    let m;
    try { m = JSON.parse(ev.data); } catch (e) { return; }
    if (m.type === 'hello') appVersion = m.version || null;
    // 설정은 storage 에 두면 페이지 쪽이 바로 받아 적용한다 (사이트 자막 숨기기 등)
    if (m.type === 'config') chrome.storage.local.set({ config: { ...DEFAULT_CONFIG, ...m.config } });
    if (m.type === 'uninstall') chrome.management.uninstallSelf({ showConfirmDialog: true });
    // Lipi 가 새 확장 파일을 꺼내 두었으면 다시 불러온다 (압축해제 설치)
    if (m.type === 'reload') chrome.runtime.reload();
  };
  ws.onclose = () => { ws = null; appVersion = null; schedule(); };
  ws.onerror = () => {};
}

// Lipi 가 꺼져 있으면 점점 덜 자주 (3초 → 최대 30초) 다시 시도한다
function schedule() {
  if (retry || !active()) return;
  retry = setTimeout(() => { retry = null; connect(); }, backoff);
  backoff = Math.min(30000, backoff * 2);
}

function post(o) {
  if (connected()) ws.send(JSON.stringify(o));
}

function siteOf(url) {
  if (!url) return null;
  if (url.includes('formula1.com')) return 'f1tv';
  if (url.includes('youtube.com')) return 'youtube';
  return null;
}

async function config() {
  const v = await chrome.storage.local.get('config');
  return { ...DEFAULT_CONFIG, ...(v.config || {}) };
}

function inject(tabId) {
  chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ['content.js'] }).catch(() => {});
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  const tab = sender.tab;
  if (tab && msg.type === 'caption') {
    touch();
    const site = siteOf(tab.url);
    config().then((c) => {
      if (!c.send || !c.sites[site]) return;
      post({ type: 'caption', tab: tab.id, site, text: msg.text, t: msg.t, lang: msg.lang, source: msg.source, title: tab.title });
    });
    return;
  }
  if (tab && msg.type === 'status') {
    if (msg.found) touch();
    post({ type: 'status', tab: tab.id, title: tab.title, site: siteOf(tab.url), source: msg.source, tracks: msg.tracks, sending: msg.sending });
    return;
  }
  if (msg.type === 'getState') {
    touch();
    config().then((c) => {
      const site = siteOf(msg.url);
      reply({ connected: connected(), appVersion, version: VERSION, site, siteOn: site ? !!c.sites[site] : false });
    });
    return true;
  }
  if (msg.type === 'inject' && msg.tabId) {
    inject(msg.tabId);
    reply({ ok: true });
  }
});

chrome.tabs.onRemoved.addListener((id) => post({ type: 'closed', tab: id }));

// 설치·새로고침하면 이미 열려 있는 탭에도 자막 찾기를 붙인다
chrome.runtime.onInstalled.addListener(async () => {
  touch();
  const list = await chrome.tabs.query({ url: chrome.runtime.getManifest().content_scripts[0].matches });
  for (const tab of list) inject(tab.id);
});

// 서비스 워커가 쉬지 않도록 20초마다 Lipi 와 주고받는다 (크롬 116 이상)
setInterval(() => { if (connected()) post({ type: 'ping' }); else if (active() && !retry && !probing) connect(); }, 20000);
