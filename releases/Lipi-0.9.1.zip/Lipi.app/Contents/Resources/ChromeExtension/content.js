// Lipi 자막 연결 — 페이지 안에서 자막 글자를 찾아 백그라운드로 넘긴다.
// 1) 영상 자막 트랙(textTracks)의 지금 자막 2) 화면에 그려진 자막 글자(사이트마다 알려진 자리, 없으면 이름에 subtitle/caption 이 든 요소)
(() => {
  // 같은 페이지에 이미 살아 있는 자막 찾기가 있으면 그만. 확장을 새로고침해 끊긴 옛것이면 새로 시작한다.
  const alive = () => { try { return !!chrome.runtime.id; } catch (e) { return false; } };
  if (window.__lipiCaptionAlive && window.__lipiCaptionAlive()) return;
  window.__lipiCaptionAlive = alive;
  document.getElementById('lipi-caption-hide')?.remove();

  const host = location.hostname;
  const SITE_SELECTORS = host.includes('youtube.com')
    ? ['.ytp-caption-window-container']
    : ['.bmpui-ui-subtitle-overlay', '.bmpui-subtitle-region-container', '.shaka-text-container', '.vjs-text-track-display'];
  const GENERIC = ['[class*="subtitle" i]', '[class*="caption" i]'];

  let last = '';
  let hide = false;
  // 탭마다: 보내기 · 숨기기 (숨기기 null = Lipi 설정의 기본값을 따름)
  let sendTab = true;
  let hideTab = null;
  let hideDefault = false;
  let sent = 0;
  let lastText = '';
  let source = null;
  let capEl = null;
  const hooked = new WeakSet();

  const style = document.createElement('style');
  style.id = 'lipi-caption-hide';

  function setHide(v) {
    hide = !!v;
    style.textContent = hide
      ? '[data-lipi-cap] { opacity: 0 !important; } video::cue { color: transparent !important; background: transparent !important; text-shadow: none !important; }'
      : '';
    if (!style.isConnected) (document.head || document.documentElement).appendChild(style);
  }

  function clean(s) {
    return (s || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function mainVideo() {
    const vs = [...document.querySelectorAll('video')];
    vs.sort((a, b) => b.clientWidth * b.clientHeight - a.clientWidth * a.clientHeight);
    return vs[0] || null;
  }

  function send(text, src, lang) {
    if (!alive()) return;
    text = clean(text);
    if (text === last) return;
    last = text;
    source = src;
    if (!text) return;
    lastText = text;
    if (!sendTab) return;
    sent += 1;
    const v = mainVideo();
    chrome.runtime.sendMessage({ type: 'caption', text, source: src, lang: lang || '', t: v ? v.currentTime : null }).catch(() => {});
  }

  function tracksInfo() {
    const v = mainVideo();
    if (!v || !v.textTracks) return [];
    return [...v.textTracks]
      .filter((t) => t.kind === 'captions' || t.kind === 'subtitles')
      .map((t) => ({ kind: t.kind, lang: t.language, label: t.label, mode: t.mode }));
  }

  // 1) 자막 트랙
  function hookTracks() {
    const v = mainVideo();
    if (!v || !v.textTracks) return false;
    let active = false;
    for (const tr of v.textTracks) {
      if (tr.kind !== 'captions' && tr.kind !== 'subtitles') continue;
      if (tr.mode === 'disabled') continue;
      active = true;
      if (!hooked.has(tr)) {
        hooked.add(tr);
        tr.addEventListener('cuechange', () => {
          if (tr.mode === 'disabled') return;
          const text = [...(tr.activeCues || [])].map((c) => c.text || '').join(' ');
          send(text, 'track', tr.language);
        });
      }
    }
    return active;
  }

  // 2) 화면 자막 글자
  function findCaptionElement() {
    for (const sel of SITE_SELECTORS) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    const v = mainVideo();
    if (!v) return null;
    const vr = v.getBoundingClientRect();
    for (const sel of GENERIC) {
      for (const el of document.querySelectorAll(sel)) {
        if (el.closest('button, [role="menu"], [class*="menu" i], [class*="setting" i]')) continue;
        const r = el.getBoundingClientRect();
        // 영상 위에 겹쳐 있는 작은 글자 상자만
        if (r.width === 0 || r.height === 0 || r.height > vr.height * 0.5) continue;
        if (r.bottom < vr.top || r.top > vr.bottom || r.right < vr.left || r.left > vr.right) continue;
        const tx = clean(el.innerText);
        if (tx && tx.length < 300) return el;
      }
    }
    return null;
  }

  function readDom() {
    if (!capEl || !capEl.isConnected) {
      if (capEl) capEl.removeAttribute('data-lipi-cap');
      capEl = findCaptionElement();
      if (capEl) capEl.setAttribute('data-lipi-cap', '');
    }
    if (!capEl) return false;
    send(capEl.innerText, 'dom', document.documentElement.lang);
    return true;
  }

  let pending = false;
  function check() {
    pending = false;
    const usingTrack = hookTracks();
    // 트랙이 켜져 있어도 화면에 그려진 자막이 따로 있으면(플레이어가 직접 그림) 그것도 읽는다
    if (!usingTrack || source !== 'track') readDom();
  }

  const observer = new MutationObserver(() => {
    if (!alive()) { observer.disconnect(); return; }
    if (pending) return;
    pending = true;
    setTimeout(check, 120);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  let lastStatus = '';
  const timer = setInterval(() => {
    if (!alive()) { clearInterval(timer); return; }
    check();
    const st = JSON.stringify({ s: source, t: tracksInfo() });
    if (st !== lastStatus) {
      lastStatus = st;
      chrome.runtime.sendMessage({ type: 'status', source, tracks: tracksInfo(), sending: sendTab, found: !!source }).catch(() => {});
    }
  }, 1500);

  function applyHide() { setHide(hideTab ?? hideDefault); }

  function state() {
    return { source, tracks: tracksInfo(), lastText, sent, send: sendTab, hide: hideTab ?? hideDefault, hasVideo: !!mainVideo() };
  }

  // 팝업이 이 탭 상태를 묻고 바꾼다 (영상이 있는 프레임이 먼저 답하고, 없으면 맨 위 프레임이 조금 뒤에 답함)
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg.type === 'getState') {
      if (mainVideo()) { reply(state()); return; }
      if (window.top !== window) return;
      setTimeout(() => reply(state()), 150);
      return true;
    }
    if (msg.type === 'setTab') {
      if ('send' in msg) sendTab = msg.send;
      if ('hide' in msg) hideTab = msg.hide;
      applyHide();
      chrome.runtime.sendMessage({ type: 'status', source, tracks: tracksInfo(), sending: sendTab, found: !!source }).catch(() => {});
      if (mainVideo() || window.top === window) reply(state());
    }
  });

  // Lipi 설정(사이트 자막 숨기기 기본값 등)은 storage 로 바로 받는다
  chrome.storage.local.get('config').then((v) => { hideDefault = !!(v.config && v.config.hideSite); applyHide(); });
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.config) { hideDefault = !!(changes.config.newValue && changes.config.newValue.hideSite); applyHide(); }
  });
})();
