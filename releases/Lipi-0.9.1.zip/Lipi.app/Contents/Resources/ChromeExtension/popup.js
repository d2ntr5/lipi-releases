// Lipi 자막 연결 — 팝업
const $ = (id) => document.getElementById(id);
let tabId = null;
let tabUrl = null;
let tabTitle = '';

function siteName(site) {
  return site === 'youtube' ? 'YouTube' : site === 'f1tv' ? 'F1 TV' : null;
}

function render(app, t, injecting) {
  const conn = $('conn');
  const color = app.connected ? '#30d158' : '#ff9f0a';
  conn.style.color = color;
  conn.innerHTML = `<i class="dot" style="background:${color}"></i>` + (app.connected ? 'Lipi 앱과 연결됨' : 'Lipi 앱이 꺼져 있음');

  const name = siteName(app.site);
  $('tab').textContent = !name
    ? '이 탭은 자막을 받는 사이트가 아닙니다 (F1 TV · formula1.com · YouTube)'
    : t ? `${tabTitle} · ${name} 규칙`
    : injecting ? '이 탭에서 자막 찾기를 시작했습니다… 안 되면 페이지를 새로고침해 주세요'
    : `${tabTitle} · ${name} 규칙`;

  const found = $('found');
  found.innerHTML = '';
  if (name && t) {
    const tracks = (t.tracks || []).filter((x) => x.mode !== 'disabled');
    if (t.source === 'track' && tracks.length) {
      found.innerHTML = `<div class="how">자막 읽는 방법: 영상 자막 트랙 (${tracks.map((x) => x.label || x.lang || x.kind).join(', ')})</div>`;
    } else if (t.source === 'dom' || t.lastText) {
      found.innerHTML = '<div class="how">자막 읽는 방법: 화면 자막 글자</div>';
    } else {
      found.innerHTML = '<div class="warn">아직 자막을 찾지 못했습니다. 플레이어에서 자막(CC)을 켜 주세요. 켜면 바로 찾습니다. 자막이 없는 영상이면 Lipi 의 “음성 인식 번역” 을 쓰세요.</div>';
    }
  }

  const on = !!(t && t.send);
  $('send').setAttribute('aria-checked', String(on));
  $('send').disabled = !t;
  $('hide').setAttribute('aria-checked', String(!!(t && t.hide)));
  $('hide').disabled = !t;
  $('sendNote').textContent = !app.connected ? 'Lipi 앱을 켜면 이어서 보냅니다'
    : name && !app.siteOn ? 'Lipi 설정에서 이 사이트가 꺼져 있습니다'
    : on ? '라이브 자막 › 사이트 자막 번역 에 바로 나옴' : '꺼짐 · 이 탭 자막을 보내지 않음';

  $('last').textContent = t && t.lastText
    ? `보낸 자막 ${t.sent}줄 · 마지막: “${t.lastText.length > 60 ? t.lastText.slice(0, 58) + '…' : t.lastText}”`
    : '';
}

let injected = false;
async function refresh() {
  const app = (await chrome.runtime.sendMessage({ type: 'getState', url: tabUrl })) || { connected: false };
  let t = null;
  if (app.site && tabId != null) {
    try {
      t = await chrome.tabs.sendMessage(tabId, { type: 'getState' });
    } catch (e) {
      // 확장을 설치·새로고침하기 전에 연 탭: 자막 찾기를 지금 붙인다
      if (!injected) {
        injected = true;
        chrome.runtime.sendMessage({ type: 'inject', tabId });
      }
    }
  }
  render(app, t, injected && !t);
}

async function setTab(patch) {
  try { await chrome.tabs.sendMessage(tabId, { type: 'setTab', ...patch }); } catch (e) {}
  refresh();
}

$('send').addEventListener('click', () => setTab({ send: $('send').getAttribute('aria-checked') !== 'true' }));
$('hide').addEventListener('click', () => setTab({ hide: $('hide').getAttribute('aria-checked') !== 'true' }));

chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
  tabId = tab ? tab.id : null;
  tabUrl = tab ? tab.url : null;
  tabTitle = tab ? tab.title || '' : '';
  refresh();
  setInterval(refresh, 1000);
});
